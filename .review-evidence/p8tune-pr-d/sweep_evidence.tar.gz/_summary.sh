#!/bin/bash
# PR-D cross-cell summary: per-cell wall + cvode key counters + rivqdown SHA12
set -euo pipefail
ROOT=/scratch/frd_muziyao/SHUD-OpenMP/.p8tune-runs/maxl_sweep
OUT=$ROOT/_summary.tsv

echo -e "case\tN\tmaxl\trep\twall_s\tnfe\tnfeLS\tnni\tnli\tnsetups\tnetf\tnst\tnpe\tnps\tncfn\tncfl\tlenrw\tleniw\tlenrwLS\tleniwLS\trivqdown_sha12\tprov_log_count" > $OUT

for case in heihe heihe_x4; do
  for N in 1 8; do
    for maxl in 5 10 15 20 30; do
      for rep in 1 2 3; do
        d=$ROOT/${case}_N${N}_maxl${maxl}_rep${rep}
        wall=$(cat $d/wall.sec 2>/dev/null | head -1)
        sha=$(sha256sum $d/rivqdown.dat 2>/dev/null | cut -c1-12)
        prov=$(grep -c "\[CVODE\] SPGMR maxl=" $d/stdout.log 2>/dev/null || echo 0)
        cs=$d/cvode_stats.txt
        nfe=$(grep "^nfe="     $cs | cut -d= -f2)
        nfeLS=$(grep "^nfeLS=" $cs | cut -d= -f2)
        nni=$(grep "^nni="     $cs | cut -d= -f2)
        nli=$(grep "^nli="     $cs | cut -d= -f2)
        nsetups=$(grep "^nsetups=" $cs | cut -d= -f2)
        netf=$(grep "^netf="   $cs | cut -d= -f2)
        nst=$(grep "^nst="     $cs | cut -d= -f2)
        npe=$(grep "^npe="     $cs | cut -d= -f2)
        nps=$(grep "^nps="     $cs | cut -d= -f2)
        ncfn=$(grep "^ncfn="   $cs | cut -d= -f2)
        ncfl=$(grep "^ncfl="   $cs | cut -d= -f2)
        lenrw=$(grep "^lenrw=" $cs | cut -d= -f2)
        leniw=$(grep "^leniw=" $cs | cut -d= -f2)
        lenrwLS=$(grep "^lenrwLS=" $cs | cut -d= -f2)
        leniwLS=$(grep "^leniwLS=" $cs | cut -d= -f2)
        echo -e "$case\t$N\t$maxl\t$rep\t$wall\t$nfe\t$nfeLS\t$nni\t$nli\t$nsetups\t$netf\t$nst\t$npe\t$nps\t$ncfn\t$ncfl\t$lenrw\t$leniw\t$lenrwLS\t$leniwLS\t$sha\t$prov" >> $OUT
      done
    done
  done
done
echo "summary written: $OUT ($(wc -l < $OUT) lines)"
